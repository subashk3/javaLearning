package excersie;

public class ConverCharInt {

	public static void main(String[] args) {
	
		char character7 = '7';
		int number7 = (int) character7;
		System.out.println(number7);
	}

}
