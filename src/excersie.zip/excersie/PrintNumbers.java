package excersie;

public class PrintNumbers {

	public static void main(String[] args) {
		int printNumber;

		// while loop
		/*while (printNumber < 11) {
			System.out.print(printNumber + " ");
			printNumber++;
		}*/

		// for loop
		for(printNumber=1;printNumber<11;printNumber++) {
			System.out.print(printNumber + " ");
		}

	}

}
