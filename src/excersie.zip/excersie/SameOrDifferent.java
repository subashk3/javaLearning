package excersie;

public class SameOrDifferent {

	public static void main(String[] args) {
		long firstNum = 6;
		long secondNum = 6L;
		if (firstNum == secondNum)
			System.out.println("Give numbers are the same.");
		else
			System.out.println("Give numbers are the different.");
			
	}
}
