package excersie;

public class SameOrDifferent2 {
	
	public static void main(String [] args) {
		
		float firstNum = 6.02f;
		double secondNum = 6.02d;
		
		if (firstNum == secondNum)
			System.out.println("Give numbers are the same.");
		else
			System.out.println("Give numbers are the different.");
		
		
		
		
		
	}

}
