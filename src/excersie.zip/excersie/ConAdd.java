package excersie;

public class ConAdd {

	public static void main(String[] args) {
		System.out.println(7+7);
		int a = 7;
		float b=7.0f;
		System.out.println(a+b);
		char c = '7';
		System.out.println(a+c);

	}
 
}
