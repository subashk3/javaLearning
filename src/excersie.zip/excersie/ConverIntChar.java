package excersie;

public class ConverIntChar {

	public static void main(String[] args) {

		int number55 = 55;
		char character55 = (char) number55;
		System.out.println(character55);
	}

}
