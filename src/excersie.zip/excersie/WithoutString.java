package excersie;

public class WithoutString {

	public static void main(String[] args) {

		float numBer = 7.50f;

		System.out.printf("%.2f", numBer);

	}

}
