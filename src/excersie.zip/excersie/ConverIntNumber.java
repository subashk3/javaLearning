package excersie;

public class ConverIntNumber {
	
	static int intNumber(float a) {
		
		int intNumber =(int) a;
		return intNumber;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float floatNumber = 150.9f;
		System.out.println("int number is :" + intNumber(floatNumber));
		
		
	}

}
