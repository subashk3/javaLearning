package excersie;

public class MobileNum {
	
	public static void main(String[] args) {

		long mobNum = 9876543210L; //long data type
		System.out.println(mobNum); 
	}

} 
